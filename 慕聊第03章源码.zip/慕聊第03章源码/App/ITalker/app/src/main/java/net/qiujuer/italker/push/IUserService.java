package net.qiujuer.italker.push;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public interface IUserService {
    String search(int hashCode);
}
