package net.qiujuer.italker.push;

import net.qiujuer.italker.common.app.Application;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class App extends Application {
}
